let basket_list = document.querySelector(".basket"); //секция корзины
let basket = document.querySelector("div"); //корзина
let product  = document.querySelectorAll(".product");
let total_items = 0; //общее кол-во
let total_price = 0; //общая цена
let none = true;

basket.addEventListener('click', function(){
	
	if(none){
		$(basket_list).hide();
		$('.product').show();	
		none = false;
	} else {
		$(basket_list).show();
		$('.product').hide();
		none = true;

	}
});

$(function () {

		$(".product img").draggable({
			revert:true
		});
        
		$(basket).droppable({
			tolerance:"touch",//хотябы на 1px над корзиной
			drop:function (event, ui) {//когда продукт оставлен в корзине
				let basket = $(this),
				move = ui.draggable,
				price = $(move).attr('data-price');
				itemId = basket.find(".basket_list li[data-id ='" + move.attr("data-id") + "']");//ID товара



				/*Если такой товар уже есть в корзине то добавляем +1 к количеству*/
				if (itemId.html() != null) {
					itemId.find("input").val(parseInt(itemId.find("input").val()) + 1);
					total_price += price;
					itemId.find(".price").text(price++);
					header.find(".data span[class = priceValue]").text(total_price);
					console.log(total_price);
					console.log(total_items);
					}
				else {
					addBasket(basket, move);
					move.find("input").val(parseInt(move.find("input").val()) + 1);
				}
			}
		});

		/*добавление товара в корзину*/
        function addBasket(basket, move) {
        	let price = $(move).attr('data-price');
			basket.find(".basket_list").after('<img data-id="' + move.attr("data-id") + '">'
					+ '<span class="name">' + move.find("data-name").html() + '</span>'
					+ '<span class="price">' + move.find("data-price").html() + '</span>'
					+ '<input class="count" value="1" type="text">'
					+ '<button class="delete">&#10005;</button>');
			total_price += parseFloat(price);
			++total_items;
			console.log(total_price);
			console.log(total_items);
			
		}
	


        // Функция для удаления товара из списка 
        $(".basket ul li button.delete").on("click", function () {
			$(this).closest("li").remove();
		});

    });